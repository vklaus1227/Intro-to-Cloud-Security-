# Lab: MITRE ATT&CK for Cloud

## 🔍 Overview
Mapped lab activity to MITRE ATT&CK cloud techniques.

| Technique | Description |
|-----------|-------------|
| T1078     | Valid Accounts |
| T1530     | Data from Cloud Storage |
| T1529     | System Shutdown/Reboot |

## Use Case
- Connected observed events from labs to known attacker behaviors
