# Intro-to-cloud-security# Intro to Cloud Security

This repository contains notes, tools, and lab exercises from my learning journey into cloud security. Topics include cloud service models, IAM, logging, compliance, and hands-on work with AWS and Azure.

## 🌩️ Topics Covered

- Cloud service & deployment models (IaaS, PaaS, SaaS / Public, Private, Hybrid)
- Identity and Access Management (IAM)
- Logging and Monitoring (AWS CloudTrail, Azure Monitor)
- S3 bucket permissions and hardening
- Cloud security tools (ScoutSuite, Prowler)
- Hands-on configuration and policy reviews

## 🔧 Tools Used

- AWS Management Console
- Azure Portal
- CLI (AWS CLI, Azure CLI)
- ScoutSuite
- Prowler

## 🧪 Labs

See the `labs/` folder for guided labs and walkthroughs.

---

**Note:** This repo is for learning purposes and reflects my progress in cloud security.
